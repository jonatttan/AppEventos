package br.com.w8digital.cadastrodeeventos.database.entity;

import android.provider.BaseColumns;

/* final na declaracao da classe proibe que outra classe herde essa classe, evitando assim que
* tente-se burlar as restrições da mesma criando uma herança dela*/
public final class EventoEntity implements BaseColumns {

    /*evitando que essa classe possa ser instanciada para novas inserções, assim eu só permito o
    uso da classe para acesso as váriaveis públicas*/
    private EventoEntity(){}

    public static final String TABLE_NAME = "evento";
    public static final String COLUMN_NAME_NOME = "nome";
    public static final String COLUMN_NAME_ENDERECO = "endereco";
    public static final String COLUMN_NAME_DATA = "data";
}
