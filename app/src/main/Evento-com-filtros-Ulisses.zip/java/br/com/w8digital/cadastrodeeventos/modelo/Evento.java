package br.com.w8digital.cadastrodeeventos.modelo;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Evento implements Serializable {

    private int id;
    private String nome;
    private String endereco;
    private String data;

    public Evento(int id, String nome, String endereco, String data){
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.data = data;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Evento(String nome, String endereco, String data ) {
        this.nome = nome;
        this.endereco = endereco;
        this.data = data;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @NonNull
    @Override
    public String toString() {
        return nome;
    }

}