package br.com.w8digital.cadastrodeeventos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import br.com.w8digital.cadastrodeeventos.database.EventoDAO;
import br.com.w8digital.cadastrodeeventos.modelo.Evento;

public class CadastroEventoActivity extends AppCompatActivity {

    private int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_evento);
        setTitle("Cadastro de Eventos");
        carregarEvento();
    }

    private void carregarEvento() {
        Intent intent = getIntent();
        if (intent != null && intent.getExtras() != null && intent.getExtras().get("eventoEdicao") != null) {
            Evento evento = (Evento) intent.getExtras().get("eventoEdicao");
            EditText editTextNome = findViewById(R.id.editText_nome);
            EditText editTextEndereco = findViewById(R.id.editText_endereço);
            EditText editTextData = findViewById(R.id.editText_data);
            editTextNome.setText(evento.getNome());
            editTextEndereco.setText(evento.getEndereco());
            editTextData.setText(evento.getData());
            id = evento.getId();
        }
    }

    public void onClickVoltar(View v) {
        finish();
    }
    public void onClickExcluir(View v) {
        EditText editTextNome = findViewById(R.id.editText_nome);
        EditText editTextEndereco = findViewById(R.id.editText_endereço);
        EditText editTextData = findViewById(R.id.editText_data);
        String nome = editTextNome.getText().toString();
        String endereco = editTextEndereco.getText().toString();
        String data = editTextData.getText().toString();
        Evento evento = new Evento(id, nome, endereco, data);
        EventoDAO eventoDAO = new EventoDAO(getBaseContext());
        boolean excluiu = eventoDAO.exluir(evento);
        if (excluiu){
            finish();
        } else {
            Toast.makeText(this, "Não é possivel excluir um evento não cadastrado.", Toast.LENGTH_LONG).show();
        }

    }
    public void onClickSalvar(View v) {
        EditText editTextNome = findViewById(R.id.editText_nome);
        EditText editTextEndereco = findViewById(R.id.editText_endereço);
        EditText editTextData = findViewById(R.id.editText_data);

        String nome = editTextNome.getText().toString();
        String endereco = editTextEndereco.getText().toString();
        String data = editTextData.getText().toString();

        if (nome.length() == 0) {
            Toast.makeText(this, "O nome está vazio", Toast.LENGTH_LONG).show();
        }else if (endereco.length() == 0) {
            Toast.makeText(this, "O endereço está vazio", Toast.LENGTH_LONG).show();
        }else if (data.length() == 0) {
            Toast.makeText(this, "A data está vazio", Toast.LENGTH_LONG).show();
        }else {
            Evento evento = new Evento(id, nome, endereco, data);
            EventoDAO eventoDAO = new EventoDAO(getBaseContext());
            boolean salvou = eventoDAO.salvar(evento);
            if (salvou){
                finish();
            } else {
                Toast.makeText(this, "Erro ao salvar", Toast.LENGTH_LONG).show();
            }
        }
            finish();
    }
}
