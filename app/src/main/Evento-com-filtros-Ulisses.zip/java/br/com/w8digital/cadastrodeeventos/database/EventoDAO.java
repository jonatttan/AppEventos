package br.com.w8digital.cadastrodeeventos.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import br.com.w8digital.cadastrodeeventos.database.entity.EventoEntity;
import br.com.w8digital.cadastrodeeventos.modelo.Evento;

public class EventoDAO {

    private final String SQL_LISTAR_TODOS = "SELECT * FROM " + EventoEntity.TABLE_NAME;
    private final String SQL_FILTRAR = "SELECT * FROM " + EventoEntity.TABLE_NAME + " WHERE " +
            EventoEntity.COLUMN_NAME_NOME + " LIKE ? ;";
    private final String SQL_LISTAR_ASC = "SELECT * FROM " + EventoEntity.TABLE_NAME + " ORDER BY " +
            EventoEntity.COLUMN_NAME_NOME + " ASC;";
    private final String SQL_LISTAR_DESC = "SELECT * FROM " + EventoEntity.TABLE_NAME + " ORDER BY " +
            EventoEntity.COLUMN_NAME_NOME + " DESC;";

    private DBGateway dbGateway;

    public EventoDAO(Context context){
        dbGateway  = DBGateway.getInstance(context);
    }

    public boolean  salvar(Evento evento){
        ContentValues contentValues = new ContentValues();
        contentValues.put(EventoEntity.COLUMN_NAME_NOME, evento.getNome());
        contentValues.put(EventoEntity.COLUMN_NAME_ENDERECO, evento.getEndereco());
        contentValues.put(EventoEntity.COLUMN_NAME_DATA, evento.getData());
        /*inserido if para verificar se ao salvar estamos inserindo uma nova ou editando uma existente verificando o id*/
        if (evento.getId() > 0){
            return dbGateway.getDatabase().update(EventoEntity.TABLE_NAME,
                    contentValues,
                    EventoEntity._ID + "=?",
                    new String[]{String.valueOf(evento.getId())}) > 0;
        }else {
            return dbGateway.getDatabase().insert(EventoEntity.TABLE_NAME, null, contentValues) > 0;
        }
    }

    public boolean  exluir(Evento evento){
        return dbGateway.getDatabase().delete(EventoEntity.TABLE_NAME,
            EventoEntity._ID + "=?",
            new String[]{String.valueOf(evento.getId())}) > 0;
    }

    public List<Evento> listar(){
        List<Evento> eventos = new ArrayList<>();
        Cursor cursor = dbGateway.getDatabase().rawQuery(SQL_LISTAR_TODOS, null);
        while(cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndex(EventoEntity._ID));
            String nome = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_NOME));
            String endereco = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_ENDERECO));
            String data = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_DATA));
            eventos.add(new Evento(id, nome, endereco, data));
        }
        cursor.close();
        return eventos;
    }

    public List<Evento> listarfiltrado(String editfiltrar){
        List<Evento> eventos = new ArrayList<>();
        Cursor cursor = dbGateway.getDatabase().rawQuery(SQL_FILTRAR,new String[]{"%"+editfiltrar+"%"});
        while(cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndex(EventoEntity._ID));
            String nome = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_NOME));
            String endereco = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_ENDERECO));
            String data = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_DATA));
            eventos.add(new Evento(id, nome, endereco, data));
        }
        cursor.close();
        return eventos;
    }

    public List<Evento> listarAsc(){
        List<Evento> eventos = new ArrayList<>();
        Cursor cursor = dbGateway.getDatabase().rawQuery(SQL_LISTAR_ASC, null);
        while(cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndex(EventoEntity._ID));
            String nome = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_NOME));
            String endereco = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_ENDERECO));
            String data = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_DATA));
            eventos.add(new Evento(id, nome, endereco, data));
        }
        cursor.close();
        return eventos;
    }

    public List<Evento> listarDesc(){
        List<Evento> eventos = new ArrayList<>();
        Cursor cursor = dbGateway.getDatabase().rawQuery(SQL_LISTAR_DESC, null);
        while(cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndex(EventoEntity._ID));
            String nome = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_NOME));
            String endereco = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_ENDERECO));
            String data = cursor.getString(cursor.getColumnIndex(EventoEntity.COLUMN_NAME_DATA));
            eventos.add(new Evento(id, nome, endereco, data));
        }
        cursor.close();
        return eventos;
    }

}
