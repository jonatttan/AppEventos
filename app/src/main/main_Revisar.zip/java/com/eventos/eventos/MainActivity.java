package com.eventos.eventos;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.eventos.eventos.modelo.Eventos;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private final int REQUEST_CODE_CADASTRO_EVENTO = 1;
    private final int RESULT_CODE_EVENTO_CADASTRADO = 2;
    private final int REQUEST_CODE_ALTERACAO_EVENTO = 3;
    private final int RESULT_CODE_EVENTO_ALTERADO = 4;
    private final int RESULT_CODE_EVENTO_EXCLUIDO = 6; //Sem uso por hora, pois não coloquei botão no CadastroEventos

    private int id = 0; //Esse valor será zero em breve

    private ListView listView_eventos; //Declaração de lisView
    private ArrayAdapter<Eventos> adapterEventos; //Declaração de ArrayAdapter

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Lista de Eventos");

        listView_eventos = findViewById(R.id.listView_eventos);
        //ArrayList<Eventos> eventosList = this.testeCadasroEventos(); //Declaração de um ArrayList que terá preenchimento para testes do ListView
        ArrayList<Eventos> eventosList = new ArrayList<Eventos>();

        adapterEventos = new ArrayAdapter<Eventos>(MainActivity.this, android.R.layout.simple_list_item_1, eventosList);
        listView_eventos.setAdapter(adapterEventos);
        funcaoOnClickListenerListView();


    }

    private void funcaoOnClickListenerListView(){
//        listView_eventos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//            final Eventos eventoClicado = adapterEventos.getItem(position);
//            Intent intent = new Intent(MainActivity.this, CadastroEventos.class);
//            intent.putExtra("eventoAlteracao", eventoClicado);
//            startActivityForResult(intent, REQUEST_CODE_ALTERACAO_EVENTO);
//            }
//        });

        listView_eventos.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final Eventos eventoLongClick = adapterEventos.getItem(position);
                final CharSequence[] opcoes = {"Excluir","Editar"};
                //ação de exclusão

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Escolha");
                builder.setItems(opcoes,
                    new DialogInterface.OnClickListener(){
                            public void onClick (DialogInterface dialog, int escolha){
                                switch (escolha){
                                    case 0:
                                        excluirEvento(eventoLongClick);
                                        Toast.makeText(MainActivity.this, "Excluido!", Toast.LENGTH_LONG).show();
                                        break;
                                    case 1:
                                        Intent intent = new Intent(MainActivity.this, CadastroEventos.class);
                                        intent.putExtra("eventoAlteracao", eventoLongClick);
                                        startActivityForResult(intent, REQUEST_CODE_ALTERACAO_EVENTO);
                                        break;
                                }
                        }
                    });
                AlertDialog dialogo = builder.create();
                dialogo.show();

                return false;
            }
        });

    }

    public void onClickCadastroEventos(View v){
        Intent intent = new Intent(MainActivity.this, CadastroEventos.class);
        startActivityForResult(intent, REQUEST_CODE_CADASTRO_EVENTO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode == REQUEST_CODE_CADASTRO_EVENTO && resultCode == RESULT_CODE_EVENTO_CADASTRADO){
            Eventos evento = (Eventos) data.getExtras().getSerializable("eventoCadastrado");
            evento.setId(++id);
            this.adapterEventos.add(evento);
        }else if(requestCode == REQUEST_CODE_ALTERACAO_EVENTO && resultCode == RESULT_CODE_EVENTO_ALTERADO){
            Eventos eventoEditado = (Eventos) data.getExtras().getSerializable("eventoAlteracao");
            for (int i = 0; i< adapterEventos.getCount(); i++){
                Eventos eventos = adapterEventos.getItem(i);
                if (eventos.getId() == eventoEditado.getId()){
                    adapterEventos.remove(eventos);
                    adapterEventos.insert(eventoEditado, i);
                    break;
                }

            }



        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void excluirEvento(Eventos eventoSelecionado){
        for (int i = 0; i < adapterEventos.getCount(); i++){
            Eventos roletaEventos = adapterEventos.getItem(i);
            if (roletaEventos.getId() == eventoSelecionado.getId()){
                adapterEventos.remove(roletaEventos);
            break;
            }
        }

    }
}
